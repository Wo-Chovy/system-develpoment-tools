import pytest
from greetlab.cli import main

def test_normal_name(monkeypatch):
    # 正常名字
    monkeypatch.setattr("sys.argv", ["sdt‑greet", "--name", "Alice"])
    main()

def test_blank_name_exit_code(monkeypatch):
    """name仅空白字符时，应当抛出SystemExit，退出码为2"""
    import sys
    monkeypatch.setattr(sys, "argv", ["sdt‑greet", "--name", "   "])
    with pytest.raises(SystemExit) as exc_info:
        main()
    assert exc_info.value.code == 2
